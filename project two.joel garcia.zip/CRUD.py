from pymongo import MongoClient
from bson.objectid import ObjectId
import urllib.parse

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, _password, _username = 'aacuser'):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = urllib.parse.quote_plus(_username)
        PASS = urllib.parse.quote_plus(_password)
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32483
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
    
    # create a record (Crud)
    def createRecord(self, data):
        if data:
            _insertValid = self.database.animals.insert_one(data)
            #check the status of the inserted value 
            return True if _insertValid.acknowledged else False

        else:
            raise Exception("No document to save. Data is empty.")
      
    # read a record (cRud)
    def readRecord(self, value):
        if value:
            _data = self.database.animals.find(value, {'_id' : 0})
                                 
        else:
            _data = self.database.animals.find({}, {'_id' : 0})
                                  
        return _data
    
    # update a record (crUd)
    def updateRecord(self, query, newValue):
        if not query:
            raise Exception("No search object is present.")
        elif not newValue:
            raise Exception("No update value is present.")
        else:
            _updateValid = self.database.animals.update_many(query, {"$set": newValue})
            self.records_updated = _updateValid.modified_count
            self.records_matched = _updateValid.matched_count

            return True if _updateValid.modified_count > 0 else False
    
    # delete a record (cruD)
    def deleteRecord(self, query):
        if not query:
            raise Exception("No search value is present.")
        
        else:
            _deleteValid = self.database.animals.delete_many(query)
            self.records_deleted = _deleteValid.deleted_count

            return True if _deleteValid.deleted_count > 0 else False  